export type Kommun = { kod: string, name: string }
export const KOMMUNER: Kommun[] = [
  { kod: '1280', name: 'Malmö' },
  { kod: '0180', name: 'Stockholm' },
  { kod: '1480', name: 'Göteborg' },
  // ...extend with your full list later
]
