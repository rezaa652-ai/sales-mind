export { default } from './(site)/page'
export const dynamic = 'force-dynamic'
